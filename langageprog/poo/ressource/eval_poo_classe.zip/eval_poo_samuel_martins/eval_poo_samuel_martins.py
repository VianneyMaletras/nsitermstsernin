
from datetime import datetime
# from utilisateur import Utilisateur
# from reseau import Reseau
liste_ami = []

# maintenant = datetime.today()
# maintenant.year
# 2024

# datetime.today()
# datetime.datetime(2023, 9, 7, 14, 33, 20, 515979)

class Utilisateur:
    
    def __init__(self, pseudo: str, mdp: float, naissance: float):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance

        """        self.get_pseudo = pseudo
        self .get_mdp = mdp
        self .get_naissance = naissance
        """

    def get_pseudo(self) -> str:
        return self.pseudo
        
    def get_mdp(self) -> float:
        return self.mdp
        
    def get_naissance(self) -> float:
        return self.naissance
        
    #### Set mdp pas bon
    """
    def set_mdp (self, mpd:float):
        while(False):
            mdp = int(input())
            if mdp < 10:
                return False
            else:
                return True
    """
    def set_mdp(self, nouv_mdp: str) -> bool:
        if len(nouv_mdp) >= 10:
            self.mdp = nouv_mdp
            return True
        else:
            return False
    def ajouter_ami (self, nouvel_ami: str):
        if nouvel_ami not in liste_ami:
            self, nouvel_ami.append(liste_ami)
        else:
            print ("Cet utilisateur est déjà dans ta liste d'ami")
    
class Reseau:
    
    def __init__ (self):
        # Vous avez mis une maj je corrige avec une minuscule self.Utilisateur = []
       self.utilisateurs=[]

    """
    def get_utilisateur(self):
        return self.utilisateurs
    """
    # Regarder la correction 
    def get_utilisateur(self, p: str) -> Utilisateur:
        for u in self.utilisateurs:
            if u.get_pseudo() == p:
                return u
        return None
    """
    def inscrire(self, psuedo:str, mpd:float, naissance:float):
        while(False):
            pseudo = str(input())
            if pseudo not in Utilisateur:
                return True
            else:
                return False
        
        while(False):# Bizarre
            naissance = int(input())
            if 2024 - naissance < 15:
                naissance = False
                print ("vous Ëtes trop jeune")
            else:
                naissance = True  
                    
        mdp = str(input())
        """  
    ## Correction 
    def inscrire(self, p: str, m: str, d: int) -> str:
        annee = datetime.now().year
        if self.existe(p):
            return p + " est déjà inscrit."
        elif d + 18 > annee:
            return p + " est trop jeune."
        else:
            nouveau = Utilisateur(p, m, d)
            self.utilisateurs.append(nouveau)
            return p + " est maintenant inscrit."
    ### Correction méthode existe
    def existe(self, p: str) -> bool:
        for u in self.utilisateurs:
            if u.get_pseudo() == p:
                return True
        return False
reseau_jay = Reseau()
assert reseau_jay.inscrire("superprof","1234567890",1977) == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

"""
Cela ne permet pas a l'utilisateur d'utiliser le mdp "12345" 
"""

assert not prof.set_mdp("12345")


""" 
Manque la méthode existe
Regarder la correction et refaites votre examen

"""