
class Utilisateur:
    def __init__(self, pseudo, mot_de_passe, annee_de_naissance):
        # Initialisation attributs
        self.pseudo = pseudo
        self.mdp = mot_de_passe
        self.naissance = annee_de_naissance
        self.amis = []

    # Accesseurs
    def get_pseudo(self):
        return self.pseudo

    def get_mdp(self):
        return self.mdp

    def get_naissance(self):
        return self.naissance

    # Mutateur modifier le mot de passe
    def set_mdp(self, nouveau_mdp):
        if len(nouveau_mdp) >= 10:  # Vérification longueur mot de passe
            self.mdp = nouveau_mdp
            return True
        else:
            return False

    # Méthode ajouter ami
    def ajouter_ami(self, ami):
        if ami not in self.amis:  # Vérification si l'ami n'est pas déjà dans la liste
            self.amis.append(ami)
            return f"{ami.get_pseudo()} est ton nouvel ami."
        else:
            return f"{ami.get_pseudo()} est déjà ton ami."