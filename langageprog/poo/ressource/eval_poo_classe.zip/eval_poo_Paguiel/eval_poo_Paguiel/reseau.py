from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        self.utilisateurs = []
        
    def get_utilisateur(self, pseudo):
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None

    def existe(self, pseudo):
        return self.get_utilisateur(pseudo) is not None

    
    def inscrire(self, pseudo, mdp, naissance):
        if self.existe(pseudo):
            return f"{pseudo} est déjà inscrit."
        
        annee_courante = datetime.now().year
        age = annee_courante - naissance
        if age < 15:
            return f"{pseudo} est trop jeune."
        
        nouvel_utilisateur = Utilisateur(pseudo, mdp, naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        return f"{pseudo} est maintenant inscrit."
