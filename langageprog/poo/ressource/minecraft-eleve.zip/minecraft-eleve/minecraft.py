#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   2021/06/24 18:14:41
"""
from random import shuffle, randint
from constantes import *
from blocs import *
from outils import *
from joueur import Joueur
from moteur import Moteur

# lancement du moteur de jeu
moteur = Moteur()

# création des blocs (15% moutons, 30% pierre, 55% terre)
grille = [None for _ in range(LARGEUR*HAUTEUR)]
nb_sheep = LARGEUR*HAUTEUR*15//100
nb_stone = LARGEUR*HAUTEUR*30//100
nb_dirt = LARGEUR*HAUTEUR*55//100
for i in range(0, nb_sheep):
    grille[i] = Mouton(randint(3, 10))
for i in range(nb_sheep, nb_sheep+nb_stone):
    grille[i] = Roche(100, "#6f6f6f")
for i in range(nb_sheep+nb_stone, LARGEUR*HAUTEUR):
    grille[i] = Terre("#a94800")

shuffle(grille)

# création de 15 outils stockés dans un dictionnaire
outils_poses = {}
# associe des coordonnées à un outil: la clé est le tuple de coordonnées
for i in range(5):
    outils_poses[moteur.donner_coordonnees()] = Pioche(False)
    outils_poses[moteur.donner_coordonnees()] = Pioche(True)
    outils_poses[moteur.donner_coordonnees()] = Pelle()

# commencer
joueur = Joueur("Christophe")
moteur.commencer(joueur, grille, outils_poses)
