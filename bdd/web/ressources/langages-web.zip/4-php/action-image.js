let images = document.querySelectorAll("img");
for (let index = 0; index < images.length; index++) {
    const imgPok = images[index];
    imgPok.addEventListener('click', function () {
        this.classList.toggle('img-zoom');
    });
}