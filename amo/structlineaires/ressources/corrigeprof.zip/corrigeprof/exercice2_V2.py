#Version 2
def creer_file() -> list:
    """
    Crée une nouvelle file vide.
    return: Une liste représentant une file vide.
    """
    return []

def est_vide(file: list) -> bool:
    """
    Vérifie si la file est vide.
    param file: La file à vérifier.
    return: True si la file est vide, False sinon.
    """
    return len(file) == 0

def defiler(file: list) -> int:
    """
    Retire et retourne le premier élément de la file.
    param file: La file d'où retirer l'élément.
    return: L'entier retiré, ou -1 si la file est vide.
    """
    if est_vide(file):
        return -1
    return file.pop(0)

def enfiler(file: list, val: int) -> None:
    """
    Ajoute un entier à la fin de la file.
    param file: La file où ajouter l'élément.
    param val: L'entier à ajouter.
    """
    file.append(val)

def inverser_file(file: list) -> None:
    """
    Inverse l'ordre des éléments d'une file.
    param file: La file à inverser.
    """
    pile = []  # Utilisation d'une pile (liste en Python)

    # Transférer les éléments de la file à la pile
    while not est_vide(file):
        pile.append(defiler(file))

    # Remettre les éléments de la pile dans la file
    while pile:
        enfiler(file, pile.pop())

def tostr(file):
    """Affiche les éléments de la file sous forme lisible."""
    return "File: " + " <- ".join(map(str, file))

def tostr(file):
    """Affiche les éléments de la file sous forme lisible."""
    return "File: " + " <- ".join(map(str, file))


# Création d'une file
file = creer_file()

# Vérification de l'état initial (file vide)
assert est_vide(file)== True, "La file devrait être vide au départ."

# Enfiler des éléments
enfiler(file,10)
enfiler(file,20)
enfiler(file,30)
assert not est_vide(file), "La file ne devrait pas être vide après enfiler des éléments."
assert tostr(file) == "File: 10 <- 20 <- 30", "La file devrait contenir les éléments dans cet ordre."

# Défiler des éléments
assert defiler(file) == 10, "Le premier élément défiler devrait être 10."
assert defiler(file) == 20, "Le deuxième élément défiler devrait être 20."
assert tostr(file) == "File: 30", "La file devrait contenir uniquement 30 après deux défilements."
assert defiler(file) == 30, "Le dernier élément défiler devrait être 30."

# Défiler une file vide
assert defiler(file) == -1, "Défiler une file vide devrait retourner -1."
assert est_vide(file)== True, "La file devrait être vide après avoir tout défilé."

# Réinitialisation de la file
enfiler(file,40)
file = creer_file()
assert est_vide(file)== True, "La file devrait être vide après réinitialisation."

# Test de la fonction inverser_file
enfiler(file,1)
enfiler(file,2)
enfiler(file,3)
inverser_file(file)
assert tostr(file) == "File: 3 <- 2 <- 1", "La file inversée devrait contenir les éléments dans l'ordre inverse."
