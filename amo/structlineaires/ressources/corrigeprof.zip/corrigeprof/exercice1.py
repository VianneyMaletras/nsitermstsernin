class Cellule:
    def __init__(self, caractere, suivant=None):
        self.caractere = caractere
        self.suivant = suivant

class Pile:
    def __init__(self):
        self.sommet = None

    def est_vide(self):
        """Renvoie True si la pile est vide, sinon False."""
        return self.sommet is None

    def empiler(self, cellule):
        """Ajoute une cellule au sommet de la pile."""
        self.sommet = Cellule(cellule, self.sommet)

        #self.sommet = Cellule(caractere, self.sommet)

    def depiler(self):
        """Dépile la cellule au sommet et renvoie le caractère ou 'vide' si la pile est vide."""
        if self.est_vide():
            return "vide"
        else:
            caractere = self.sommet.caractere
            self.sommet = self.sommet.suivant
            return caractere

def bien_formee(chaine: str) -> bool:
    """Vérifie si la chaîne est bien formée en respectant les parenthèses, crochets et accolades."""
    pile = Pile()
    associe = {")": "(", "]": "[", "}": "{"}

    for caractere in chaine:
        if caractere in "({[":
            pile.empiler(Cellule(caractere))
        elif caractere in ")}]":
            sommet = pile.depiler()
            if sommet == "vide" or sommet != associe[caractere]:
                return False

    return pile.est_vide()
def bien_formee_v2(chaine: str) -> bool:
    """Vérifie si une chaîne est bien formée."""
    associe = {")": "(", "]": "[", "}": "{"}
    pile = Pile()

    for char in chaine:
        if char in "([{":
            # Si le caractère est un signe ouvrant, on l'empile
            pile.empiler(char)
        elif char in ")]}":
            # Si le caractère est un signe fermant
            if pile.est_vide():
                return False  # Mal formée : pile vide
            sommet = pile.depiler()
            if associe[char] != sommet:
                return False  # Mal formée : signe ouvrant ne correspond pas
    return pile.est_vide()  # Bien formée si la pile est vide à la fin



# Tests unitaires pour la fonction bien_formee
assert bien_formee_v2("([])") == True  # Cas simple, chaîne bien formée
assert bien_formee_v2("({[()]})") == True  # Imbrication correcte
assert bien_formee_v2("[{()}]") == True  # Imbrication avec plusieurs types

assert bien_formee_v2("(]") == False  # Parenthèse fermante ne correspond pas
assert bien_formee_v2("({[}") == False  # Manque des fermetures
assert bien_formee_v2("]") == False  # Fermeture sans ouverture
assert bien_formee_v2("(((())))") == True  # Parenthèses imbriquées correctement
assert bien_formee_v2("{[(])}") == False  # Parenthèses mal imbriquées

print("Tous les tests sont passés avec succès !")



# quasi Parfait pour cet exercice moins les docstring et l'inattention dans la fonction empiler 8/10