from datetime import datetime
from utilisateur import Utilisateur

maintenant = datetime.today()

class Reseau:
    def __init__ (self):
        self.utilisateur = []

    def get_utilisateur(self):
        if pseudo in utilisateur:
            return utilisateur
        else:
            return None
"""
    def exist(self):# Vous avez changé la signature de la méthode
       if speudo in utilisateur:
       
            return True
        return False
    """
     def existe(self, pseudo: str) -> bool:
        return any(utilisateur.get_pseudo() == pseudo for utilisateur in self.utilisateurs)
    #def inscrire(self, naissance:int,mdp:str,pseudo:str):# Mauvaise signature du coup tout est faussé
    def inscrire(self, pseudo: str, mdp: str, naissance: int) -> str:
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        for utilisateur in self.utilisateur:
            if pseudo == utilisateur.get_pseudo():
            # if pseudo in utilisateur:
                # if naissance - maintenant.year <= 15:
                if  maintenant.year- naissance <= 15:
                    return self.pseudo+ " est trop jeune."
                return self.pseudo+ " est maintenant inscrit."
            else:
                return self.utilisateur.append(Utilisateur)
