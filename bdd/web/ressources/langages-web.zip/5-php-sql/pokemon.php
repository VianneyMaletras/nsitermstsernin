<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokémon</title>

    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php
// Initialisation de la connexion
$servername = "localhost";
$dbname = "pokemon";
$username = "bigboss";
$password = "supermdp";

$connexion = mysqli_connect($servername, $username, $password, $dbname) or die ("connexion impossible");
?> 

    <div id="contenu">
        <h1>Tous les Pokémon</h1>
        <table id="pok">

<?php
// requête sur la BDD
$query = "SELECT nom FROM Pokemon";
$result = mysqli_query($connexion,$query);
	
$lig = 0;
if($result){
    // parcours du résultat de la requête
	while($row = mysqli_fetch_array($result)){
        if ($lig % 4 == 0){
            echo "<tr>";
        }
        
		$name = $row["nom"];
        echo "<td><img src='img/".$name.".png'></td>";

        if ($lig == 3){
            echo "</tr>";
            $lig= -1;
        }
        $lig=$lig+1;
	}
}

// fermeture de la connexion
mysqli_free_result($result);
mysqli_close($connexion);
?>

        </table>
    </div>


    <script src="action-image.js"></script>

</body>

</html>
