from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self, utilisateurpseudo_utilisateur):
        self.tab_utilisateur = []
        self.pseudo_utilisateur = pseudo_utilisateur
        self.inscrire

    def get_utilisateur(self):
        if utilisateur in self.tab_utilisateur:
            return pseudo_utilisateur:
                else return None


    def self.pseudo_utilisateur(pseudo_uilisateur)->bool:
        for utilisateur in return True if utilisateur in self.utilisateur:
            else return False

    def inscrire(pseudo_utilisateur: str, mdp_utilisateur : str, naissance_utilisateur: int)->str:
        if pseudo_utilisateur in self.tab_utilisateur:
            return(pseudo, "déjà inscrit")
        if naissance_utilisateur > 2009
