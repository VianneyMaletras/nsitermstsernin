class Utilisateur:
    def __init__(self, pseudo:str, mdp:str, naissance:int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.amis = []

    def get_pseudo(self):
        return self.pseudo

    def get_mdp(self):
        return self.mdp

    def get_naissance(self):
        return self.naissance

    def set_mdp(self, nv_mdp):
        if len(nv_mdp) >= 10:
            self.mdp = nv_mdp
            return True
        return False

    def ajouter_ami(self, ami):
        if ami not in self.amis:
            self.amis.append(ami)
            return ami.get_pseudo()+ " est ton nouvel ami."
        return ami.get_pseudo()+ " est déjà ton ami."