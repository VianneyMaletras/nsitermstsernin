COULEURS = ["pique", "coeur", "carreau", "trèfle"]
FIGURES = {11: "valet", 12: "dame", 13: "roi", 14: "as"}
