<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokémon</title>

    <link rel="stylesheet" href="style.css">
</head>

<body>
    
    <div id="contenu">
        <h1>Tous les Pokémon</h1>
        <table id="pok">
            
<?php
    //lecture du json
    $jsonFichier = file_get_contents("pokedex.json");
    $tabPok = json_decode($jsonFichier, true)["pokemon"];

    $lig = 0;
    while ($lig < count($tabPok)) {
        echo "<tr>";

        for ($col=0; $col<4; $col++) {
            if ($lig+$col<count($tabPok)){
                echo "<td><img src='img/".$tabPok[$lig+$col]['name'].".png'></td>";
            }
        }
        echo "</tr>";
        $lig=$lig+4;
    }
?>

        </table>
    </div>


    <script src="action-image.js"></script>

</body>

</html>
