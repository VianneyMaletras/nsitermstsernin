class Element:
    '''
    Représente un élément d'une pile avec une valeur et un lien vers l'élément suivant.

            Parameters:
                    val (int): La valeur de l'élément.
                    suivant (Element, optional): Référence vers l'élément suivant dans la pile (ou None si c'est le dernier).

            Attributes:
                    valeur (int): La valeur de l'élément.
                    suivant (Element): Référence vers l'élément suivant.
    '''
    def __init__(self, val: int, suivant: object = None):
        self.valeur = val
        self.suivant = suivant


class Pile:
    '''
    Implémentation de base d'une pile utilisant une liste Python.

            Attributes:
                    elements (list): Liste contenant les éléments de la pile.
    '''
    def __init__(self):
        self.elements = []

    def est_vide(self) -> bool:
        '''
        Vérifie si la pile est vide.

                Returns:
                        (bool): True si la pile est vide, False sinon.
        '''
        return len(self.elements) == 0

    def empiler(self, e: int) -> None:
        '''
        Ajoute un élément au sommet de la pile.

                Parameters:
                        e (int): L'élément à ajouter.
        '''
        self.elements.append(e)

    def depiler(self) -> int:
        '''
        Retire et retourne l'élément au sommet de la pile.

                Returns:
                        (int): L'élément retiré.

                Raises:
                        IndexError: Si la pile est vide.
        '''
        if self.est_vide():
            raise IndexError("Pile vide")
        return self.elements.pop()


class PileG(Pile):
    '''
    Implémentation d'une pile utilisant une structure chaînée (liste chaînée).

            Attributes:
                    sommet (Element): Référence vers l'élément au sommet de la pile.
    '''
    def __init__(self):
        self.sommet = None

    def est_vide(self) -> bool:
        '''
        Vérifie si la pile est vide.

                Returns:
                        (bool): True si la pile est vide, False sinon.
        '''
        return self.sommet is None

    def empiler(self, e: int) -> None:
        '''
        Ajoute un élément au sommet de la pile.

                Parameters:
                        e (int): L'élément à ajouter.
        '''
        self.sommet = Element(e, self.sommet)

    def depiler(self) -> int:
        '''
        Retire et retourne l'élément au sommet de la pile.

                Returns:
                        (int): La valeur de l'élément retiré.

                Raises:
                        IndexError: Si la pile est vide.
        '''
        if self.est_vide():
            raise IndexError("Pile vide")
        val_elem = self.sommet.valeur
        self.sommet = self.sommet.suivant  # Passe à l'élément suivant
        return val_elem


class PileD(Pile):
    '''
    Implémentation d'une pile où les éléments sont toujours insérés au début de la liste.

            Attributes:
                    elements (list): Liste contenant les éléments de la pile.
    '''
    def __init__(self):
        super().__init__()

    def empiler(self, e: int) -> None:
        '''
        Ajoute un élément au sommet de la pile (en début de liste).

                Parameters:
                        e (int): L'élément à ajouter.
        '''
        self.elements.insert(0, e)

    def depiler(self) -> int:
        '''
        Retire et retourne l'élément au sommet de la pile (début de liste).

                Returns:
                        (int): L'élément retiré.

                Raises:
                        IndexError: Si la pile est vide.
        '''
        if self.est_vide():
            raise IndexError("Pile vide")
        return self.elements.pop(0)


class File:
    '''
    Implémentation d'une file utilisant deux piles.
    La file suit le principe FIFO (First In, First Out).

            Attributes:
                    pile_gauche (PileG): Pile utilisée pour enfiler les éléments.
                    pile_droite (PileG): Pile utilisée pour défiler les éléments.
    '''
    def __init__(self):
        self.pile_gauche = PileG()
        self.pile_droite = PileG()

    def est_vide(self) -> bool:
        '''
        Vérifie si la file est vide.

                Returns:
                        (bool): True si la file est vide, False sinon.
        '''
        return self.pile_gauche.est_vide() and self.pile_droite.est_vide()

    def enfiler(self, e: int) -> None:
        '''
        Ajoute un élément à la fin de la file.

                Parameters:
                        e (int): L'élément à ajouter.
        '''
        self.pile_gauche.empiler(e)

    def defiler(self) -> int:
        '''
        Retire et retourne le premier élément de la file.

                Returns:
                        (int): Le premier élément de la file.

                Raises:
                        IndexError: Si la file est vide.
        '''
        if self.pile_droite.est_vide():
            # Déplace tous les éléments de pile_gauche vers pile_droite
            while not self.pile_gauche.est_vide():
                self.pile_droite.empiler(self.pile_gauche.depiler())
        if self.pile_droite.est_vide():
            raise IndexError("File vide")
        return self.pile_droite.depiler()

    
# Tests pour la classe Pile
def test_pile():
    pile = Pile()
    assert pile.est_vide() == True, "Pile devrait être vide"
    pile.empiler(1)
    pile.empiler(2)
    assert pile.est_vide() == False, "Pile ne devrait pas être vide"
    assert pile.depiler() == 2, "Dernier élément devrait être 2"
    assert pile.depiler() == 1, "Dernier élément devrait être 1"
    try:
        pile.depiler()
    except IndexError:
        assert True, "Pile vide devrait lever IndexError"

# Tests pour la classe PileG
def test_pile_G():
    pile = PileG()
    assert pile.est_vide() == True, "PileG devrait être vide"
    pile.empiler(1)
    pile.empiler(2)
    assert pile.est_vide() == False, "PileG ne devrait pas être vide"
    assert pile.depiler() == 2, "Dernier élément de PileG devrait être 2"
    assert pile.depiler() == 1, "Dernier élément de PileG devrait être 1"
    try:
        pile.depiler()
    except IndexError:
        assert True, "PileG vide devrait lever IndexError"

# Tests pour la classe PileD
def test_pile_droite():
    pile = PileD()
    assert pile.est_vide() == True, "PileD devrait être vide"
    
    pile.empiler(1)
    pile.empiler(2)
    assert pile.est_vide() == False, "PileD ne devrait pas être vide"
    
    # Les assertions corrigées pour correspondre à l'ordre attendu dans PileD
    assert pile.depiler() == 2, "Dernier élément empilé devrait être 2"
    assert pile.depiler() == 1, "Dernier élément restant devrait être 1"
    
    try:
        pile.depiler()
    except IndexError:
        assert True, "PileD vide devrait lever une exception IndexError"

        assert True, "PileD vide devrait lever IndexError"

# Tests pour la classe File
def test_File():
    file = File()
    assert file.est_vide() == True, "File devrait être vide"
    file.enfiler(1)
    file.enfiler(2)
    file.enfiler(3)
    assert file.est_vide() == False, "File ne devrait pas être vide"
    assert file.defiler() == 1, "Premier élément de File devrait être 1"
    assert file.defiler() == 2, "Deuxième élément de File devrait être 2"
    assert file.defiler() == 3, "Troisième élément de File devrait être 3"
    try:
        file.defiler()
    except IndexError:
        assert True, "File vide devrait lever IndexError"

# Exécution des tests
if __name__ == "__main__":
    test_pile()
    print("Tests pour Pile passés avec succès.")
    test_pile_G()
    print("Tests pour PileG passés avec succès.")
    test_pile_droite()
    print("Tests pour PileD passés avec succès.")
    test_File()
    print("Tests pour File passés avec succès.")
