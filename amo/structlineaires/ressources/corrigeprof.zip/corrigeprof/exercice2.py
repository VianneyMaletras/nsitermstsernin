class Element:
    def __init__(self, donnees: int, successeur: object = None):
        self.donnees = donnees
        self.successeur = successeur

class Pile:
    def __init__(self):
        self.sommet = None

    def est_vide(self) -> bool:
        return self.sommet is None

    def empiler(self, donnees: int) -> None:
        self.sommet = Element(donnees, self.sommet)

    def depiler(self) -> int:
        if not self.est_vide():
            retour = self.sommet.donnees
            self.sommet = self.sommet.successeur
            return retour
        return -1  # Retourne -1 si la pile est vide

    def __str__(self) -> str:
        affichage = ""
        current = self.sommet
        while current is not None:
            affichage += str(current.donnees) + " ↵\n"
            current = current.successeur
        return affichage if affichage else "Pile vide"


class File:
    def __init__(self):
        """Initialise une file vide."""
        self.elements = []

    def creer_file(self) -> None:
        """Réinitialise la file à une file vide."""
        self.elements=[]
        return self.elements

    def est_vide(self) -> bool:
        """Vérifie si la file est vide."""
        return len(self.elements) == 0

    def enfiler(self, val: int) -> None:
        """Ajoute un élément à la fin de la file."""
        self.elements.append(val)

    def defiler(self) -> int:
        """Retire et retourne l'élément en tête de la file.
        Retourne -1 si la file est vide.
        """
        return self.elements.pop(0) if not self.est_vide() else -1

    def __str__(self):
        """Affiche les éléments de la file sous forme lisible."""
        return "File: " + " <- ".join(map(str, self.elements))

def inverser_file(file: File) -> File:
    pile = Pile()
    # Défilement de la file dans la pile
    while not file.est_vide():
        pile.empiler(file.defiler())

    # Réempilement dans la file
    while not pile.est_vide():
        file.enfiler(pile.depiler())

    return file



# Création d'une file
file = File()

# Vérification de l'état initial (file vide)
assert file.est_vide() == True, "La file devrait être vide au départ."

# Enfiler des éléments
file.enfiler(10)
file.enfiler(20)
file.enfiler(30)
assert not file.est_vide(), "La file ne devrait pas être vide après enfiler des éléments."
assert str(file) == "File: 10 <- 20 <- 30", "La file devrait contenir les éléments dans cet ordre."

# Défiler des éléments
assert file.defiler() == 10, "Le premier élément défiler devrait être 10."
assert file.defiler() == 20, "Le deuxième élément défiler devrait être 20."
assert str(file) == "File: 30", "La file devrait contenir uniquement 30 après deux défilements."
assert file.defiler() == 30, "Le dernier élément défiler devrait être 30."

# Défiler une file vide
assert file.defiler() == -1, "Défiler une file vide devrait retourner -1."
assert file.est_vide() == True, "La file devrait être vide après avoir tout défilé."

# Réinitialisation de la file
file.enfiler(40)
file.creer_file()
assert file.est_vide() == True, "La file devrait être vide après réinitialisation."

# Test de la fonction inverser_file
file.enfiler(1)
file.enfiler(2)
file.enfiler(3)
inverser_file(file)
assert str(file) == "File: 3 <- 2 <- 1", "La file inversée devrait contenir les éléments dans l'ordre inverse."
print("Tous les tests sont passés avec succès !")

