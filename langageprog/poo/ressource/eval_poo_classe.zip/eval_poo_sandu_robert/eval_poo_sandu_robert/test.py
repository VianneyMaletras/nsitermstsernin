from reseau import Reseau

reseau_jay = Reseau()
assert reseau_jay.inscrire("superprof","1234567890",1977) == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","1234567890",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
#assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateurs("superprof")
eleve = reseau_jay.get_utilisateurs("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345")

"""
Bon travail quelques erreurs, regardez la correction. 
Je n'ai pas vu la réponse à la question sur l'assert. Si j'ai mal lu veuillez m'en corriger 
17/20
"""