<?php

// Initialisation de la connexion
$servername = "localhost";
$dbname = "pokemon";
$username = "bigboss";
$password = "supermdp";

$connexion = mysqli_connect($servername, $username, $password, $dbname) or die ("connexion impossible");

// requête sur la BDD
$query1 = "CREATE TABLE IF NOT EXISTS type(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nom CHAR(50) NOT NULL)";

$query2 = "CREATE TABLE IF NOT EXISTS weaknesses(
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nom CHAR(50) NOT NULL)";

$query3 = "CREATE TABLE IF NOT EXISTS pok(
    id INT UNSIGNED NOT NULL PRIMARY KEY,
    nom VARCHAR(50),
    poids VARCHAR(10),
    taille VARCHAR(10))";

$query4 = "CREATE TABLE IF NOT EXISTS affectation_type(
    id_type INT UNSIGNED NOT NULL,
    id_pok INT UNSIGNED NOT NULL,
    PRIMARY KEY (id_type, id_pok),
    FOREIGN KEY (id_type) REFERENCES type(id),
    FOREIGN KEY (id_pok) REFERENCES pok(id))";

$query5 = "CREATE TABLE IF NOT EXISTS affectation_weaknesses(
    id_weaknesses INT UNSIGNED NOT NULL,
    id_pok INT UNSIGNED NOT NULL,
    PRIMARY KEY (id_weaknesses, id_pok),
    FOREIGN KEY (id_weaknesses) REFERENCES weaknesses(id),
    FOREIGN KEY (id_pok) REFERENCES pok(id))";

if (mysqli_query($connexion,$query1)) {
    echo "type OK <br>";
} else {
    echo "Erreur type: " . mysqli_error($connexion);
}
	
if (mysqli_query($connexion,$query2)) {
    echo "weaknesses OK <br>";
} else {
    echo "Erreur weaknesses: " . mysqli_error($connexion);
}

if (mysqli_query($connexion,$query3)) {
    echo "pok OK <br>";
} else {
    echo "Erreur pok: " . mysqli_error($connexion);
}

if (mysqli_query($connexion,$query4)) {
    echo "affectation_type OK <br>";
} else {
    echo "Erreur affectation_type: " . mysqli_error($connexion);
}

if (mysqli_query($connexion,$query5)) {
    echo "affectation_weaknesses OK <br>";
} else {
    echo "Erreur affectation_weaknesses: " . mysqli_error($connexion);
}

// fermeture de la connexion
mysqli_close($connexion);
?> 
