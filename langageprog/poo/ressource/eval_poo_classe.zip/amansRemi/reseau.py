from datetime import datetime
from utilisateur import Utilisateur


class Reseau:

    def __init__(self):
        self.utilisateur = []

    def get_utilisateur(self):
        return self.utilisateur

    def existe(self, pseudo: str):
        for util in self.utilisateur:
            if pseudo == util.get_pseudo():
                return True
        return False
        # while(False):####????????
        #     #if pseudo in utilisateur:
        #     if pseudo ==self.utilisateur.get_pseudo():
        #         return False
        #     else:
        #         return  True
"""
    def inscrire(self, pseudo: str, mdp: str, naissance: float)->str:
        if pseudo in utilisateurs:
            return pseudo +" est déjà inscrit."


        if 2024 - naissance < 15:
            return pseudo+" est trop jeune."

        else:
             utilisateurs.append(amis)
             return pseudo+" est maintenant inscrit."
"""

def inscrire(self, p: str, m: str, d: int) -> str:
        annee = datetime.now().year
        if self.existe(p):
            return p + " est déjà inscrit."
        elif d + 18 > annee:
            return p + " est trop jeune."
        else:
            nouveau = Utilisateur(p, m, d)
            self.utilisateurs.append(nouveau)
            return p + " est maintenant inscrit."

