from datetime import datetime
from utilisateur import Utilisateur


class Reseau:
    def __init__(self):
        self.utilisateur = []


    def get_utilisateur(self,pseudo:str):
        self.pseudo = pseudo
        if self.pseudo in self.utilisateur:
            util = Utilisateur.get_pseudo
            return util
        else:
            return None

    def inscrits(self,pseudo_u:str):
        ## innatention pseudo_u et pas pseudo 
        self.pseudo = pseudo
        if self.pseudo in self.utilisateur:
            return True
        else:
            return False

    def inscrire(self,pseudo_n:str,mdp_n:str,birthyear_n:int):
        self.pseudo = pseudo_n
        self.mdp = mdp_n
        self.birthyear = birthyear_n
        maintenant = datetime.today()
        if self.pseudo in self.utilisateur:
            print(self.pseudo+" est déjà inscrit.")
        elif maintenant.year -self.birthyear <= 15:
            return (self.pseudo+" est trop jeune.")
        else:
            pseudo = (self.pseudo,self.mdp,self.birthyear)
            self.utilisateur.append(pseudo)
            message=self.pseudo+" est maintenant inscrit."
            return message




