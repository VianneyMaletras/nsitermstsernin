from carte import Carte
from random import shuffle
from constantes import COULEURS


class Jeu:
    """
    crée un jeu de 32 cartes
    """
    def __init__(self) -> None:
        self.paquet = ...
        for c in COULEURS:
            for i in ...(7, 15):
                self.paquet.append(...)