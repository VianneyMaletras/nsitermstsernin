#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   2021/06/22 23:52:14
"""

from constantes import *
from blocs import Terre, Roche, Mouton


class Pioche:
    def __init__(self, diamant: bool):
        self.est_diamant = diamant
        if self.est_diamant:
            self.resistance = 100
            self.impact = 50
        else:
            self.resistance = 30
            self.impact = 5

    def piocher(self, bloc: object) -> bool:
        """
        donne un coup sur le bloc (roche ou mouton)

        Args:
            bloc (object): l'objet visé

        Returns:
            bool: True si l'outil est complètement usé
        """
        if isinstance(bloc, Roche):
            bloc.subir_impact(self.impact)
            self.resistance = self.resistance - USURE            
        elif isinstance(bloc, Mouton):
            bloc.assommer()
            
        # la pioche est usée
        if self.resistance <= 0:
            return True
        else:
            return False


class Pelle:
    def __init__(self):
        self.resistance = 50
        self.impact = 0

    def utiliser_pelle(self, bloc: object) -> bool:
        """
        laboure un bloc terre ou 
        assomme un mouton

        Args:
            bloc (object): l'objet visé'

        Returns:
            bool: True si l'outil est complètement usé
        """
        if isinstance(bloc, Terre):
            bloc.labourer()
            self.resistance = self.resistance - USURE
        elif isinstance(bloc, Mouton):
            bloc.assommer()
        
        # la pioche est usée
        if self.resistance <= 0:
            return True
        else:
            return False
