class Utilisateur:
    def __init__(self, pseudo:str, mdp: str, naissance: int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.ami = []
    def get_pseudo(self):
        return get_pseudo

    def get_mdp(self):
        return get_mdp 

    def get_naissance(self):
        return get_naissance
    
    def set_mdp (bool):
        if len(set_mdp) >= 10:
            return True
        else:
            return False
        
    def ajouter_ami (self, Utilisateur):
        if nouvel = is not in self.ami:
            self.ami.append(pseudo):
            return f"pseudo est ton nouvel ami"
        else:
        return f"pseudo est déjà ton ami."
