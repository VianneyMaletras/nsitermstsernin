from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur(self, pseudo):
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None

    def existe(self, pseudo):
        return any(utilisateur.get_pseudo() == pseudo for utilisateur in self.utilisateurs)

    def inscrire(self, pseudo, mdp, naissance):
        if self.existe(pseudo):
            return pseudo+" est déjà inscrit."

        # Vérification de l'âge
        annee_actuelle = datetime.today().year
        if annee_actuelle - naissance < 15:
            return pseudo+" est trop jeune."

        # Inscription de l'utilisateur
        nouvel_utilisateur = Utilisateur(pseudo, mdp, naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        return pseudo+ " est maintenant inscrit."

