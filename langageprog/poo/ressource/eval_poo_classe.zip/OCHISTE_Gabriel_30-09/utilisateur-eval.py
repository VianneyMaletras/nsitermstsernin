class Utilisateur:
    def __init__(self,pseudo:str,mdp:str,naissance:int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
    def get_pseudo(self) -> str:
        return self.pseudo
    def get_mdp(self) -> str:
        return self.mdp
    def get_naissance(self) -> int:
        return self.naissance
    def set_mdp(self,mdp):
        if len(mdp) >= 10:
            #innatention self.mdp =nouveau_mdp
            self.mdp =mdp
            return True
        else:
            return False
    def ajouter_amis(self,ami):
        if ami in self.amis: # inatention if nouvel_ami in self.amis:
            return print("{ami.pseudo} est deja ton ami")
        else:
            self.amis.append(ami)
            return print("{(ami.pseudo} est ton nouvel ami")


