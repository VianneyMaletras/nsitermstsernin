class Utilisateur:
    def __init__(self, pseudonyme:str, motdepasse:str, datedenaissance:int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.tab_amis = []



    def set_mdp(self)->bool:
        self.mdp = " "
        if self.mdp >= 10:
            return True
        else:
            return False

    def ajouter_amis(self, amis, pseudo)->str:
        if self.pseudo not in tab_amis:
            tab_amis.append(pseudo)
            return (pseudo,"est ton  nouvel amis")
        else:
             return(pseudo,"est déjà ton amis")

