#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   2021/06/22 23:42:38
"""


class Terre:
    def __init__(self, c: str):
        self.couleur = c
        self.est_labouree = False
