from constantes import FIGURES


class Carte:
