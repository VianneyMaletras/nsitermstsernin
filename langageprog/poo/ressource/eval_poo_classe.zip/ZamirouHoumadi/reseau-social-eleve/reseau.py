from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur(self, pseudo: str):
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None

    def existe(self, pseudo: str) -> bool:
        return any(utilisateur.get_pseudo() == pseudo for utilisateur in self.utilisateurs)

    def inscrire(self, pseudo: str, mdp: str, naissance: int) -> str:
        if self.existe(pseudo):
            return f"{pseudo} est déjà inscrit."

        maintenant = datetime.today()
        annee_actuelle = maintenant.year
        age = annee_actuelle - naissance

        if age < 15:
            return f"{pseudo} est trop jeune."

        nouvel_utilisateur = Utilisateur(pseudo, mdp, naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        return f"{pseudo} est maintenant inscrit."
