class Utilisateur:
    def __init__(self,nom:str,mdp:str,birthyear:int):
        self.nom = nom
        self.mdp = mdp
        self.birthyear = birthyear

    def get_utilisateur(self):
        return self.nom

    def get_mot_de_passe(self):
        return self.mdp

    def get_date(self):
        return self.birthyear
    ### le setter est fait pour changer la valeur de la propriété. Il n'y a pas lieu de mettre un input et un print. 
    def set_mdp(self):
        if len(self.mdp) >= 9:
            print("Quel est le nouveau mot de passe ?")# ???
            self.mdp = str(input())
            return True
        else:
            return False

    def ajouter_ami(self,amis:[],newami:str):# illogique de faire des amis un tableau cela doit être utilisateur
        self.newami = newami
        self.ami = ami
        if self.newami not in self.ami:
            self.ami.append(self.newami)
            return (self.newami+" est ton nouvel ami.".format(self.newami))
        else:
            return (self.newami+" est déjà ton ami.".format(self.newami))