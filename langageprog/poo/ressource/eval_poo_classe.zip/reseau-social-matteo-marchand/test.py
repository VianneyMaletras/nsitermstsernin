from reseau import Reseau

reseau_jay = Reseau()
inscrire =reseau_jay.inscrire("superprof","1234567890",1977)
assert inscrire== "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345")
#cela empeche l'utilisateur d'utilier le mot de passe 12345

""" 
Vous avez changé les signatures des méthodes du coup le programme ne marche pas. 
Vous devez revoir le parcours d'objets imbriqués. 
Je ne peux pas metre la moyenne nous ferons un rattrapage si cela vous convient. 
8/10
"""