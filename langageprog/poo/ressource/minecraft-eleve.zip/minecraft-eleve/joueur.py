#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   2021/06/24 17:38:16
"""

from constantes import *
from outils import *


class Joueur:
    def __init__(self, n: str):
        self.nom = n
        self.x = 0
        self.y = 0
        self.outils = []  # 5 maxi
        self.blocs = {"dirt": 0, "stone": 0, "sheep": 0}
        self.en_main = 0  # outil en main

    def agir(self, bloc: object) -> bool:
        """
        action sur un bloc en fonction de l'outil

        Args:
            bloc (object): le bloc miné

        Returns:
            bool: True si le bloc est complètement miné
        """
        # un outil en main
        if self.en_main < len(self.outils):
            # récupération outil
            outil = self.outils[self.en_main]
            if isinstance(outil, Pelle):  # pelle
                usee = outil.utiliser_pelle(bloc)
            else:  # pioche
                usee = outil.piocher(bloc)

            if usee:
                self.outils.pop(self.en_main)

    def ramasser_outil(self, outil: object) -> None:
        """
        place l'outil dans l'inventaire s'il y a de la place

        Args:
            outil (object): l'outil ramassé

        Returns:
            bool: True si l'outil a été ramassé
        """
        if len(self.outils) < NB_OUTILS_INVENTAIRE:
            # l'outil est ajouté à l'inventaire
            self.outils.append(outil)
            return True
        return False

    def ramasser_bloc(self, bloc: object) -> bool:
        """
        met à jour le score

        Args:
            bloc (object): le bloc ramassé

        Returns:
            bool: True si le bloc a été ramassé
        """
        if isinstance(bloc, Terre) and bloc.est_labouree:
            self.blocs["dirt"] = self.blocs["dirt"] + 1
            return True
        elif isinstance(bloc, Roche) and bloc.est_minee:
            self.blocs["stone"] = self.blocs["stone"] + 1
            return True
        elif isinstance(bloc, Mouton) and bloc.est_assomme:
            # ajoute la quantité de laine
            laine = bloc.tondre()
            self.blocs["sheep"] = self.blocs["sheep"] + laine
            return True
        return False
