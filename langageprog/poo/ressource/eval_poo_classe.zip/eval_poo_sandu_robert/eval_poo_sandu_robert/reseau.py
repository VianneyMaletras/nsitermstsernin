from datetime import datetime
from utilisateur import Utilisateur

class Reseau :
    def __init__(self, ):
        self.utilisateurs = []
    """
    def get_utilisateurs(self, pseudo :str):
        for utilisateur in self.utilisateurs :
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
            else :
                return None
    """
    # Correction aide 
    def get_utilisateurs(self, pseudo :str):
        for utilisateur in self.utilisateurs :
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None
        
    def existe(self, pseudo :str):  
        self.get_utilisateurs(pseudo) is not None
        
    def inscrire(self, pseudo : str, mdp : str, naissance : int):
        if self.existe(pseudo):
            return f"{pseudo} est déjà inscrit."
        age = 2024 - naissance
        if age < 15:
            return f"{pseudo} est trop jeune."
        nouvel_utilisateur = Utilisateur(pseudo, mdp, naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        return f"{pseudo} est maintenant inscrit."