class Utilisateur:
    def __init__ (self,pseudo : str,mdp : str,naissance:int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.new_mdp = False
        self.amis = []

    def get_pseudo(self):
        return self.speudo

    def get_mdp(self):
        return self.mdp

    def get_naissance(self):
        return self.naissance

    def set_mdp(self):
        while(False): # what???? jamais exécuté je pense
            if len(new_mdp)>=10:
                self.mdp = new_mdp
                return True
            return False

    def ajouter_amis(self, amis_new:str):
        if amis_new in self.amis:
        #if amis in self.amis: # amis n'existe pas . 
            print(f"{amis_new} est deja votre ami")
        else:
            print(f"{amis_new}est devenu votre ami")
            self.amis.append(amis_new)
