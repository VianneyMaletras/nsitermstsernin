from datetime import datetime
from utilisateur import Utilisateur

class Reseau:

    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur(self, pse:str):
        for i in self.utilisateurs:
            if i.pseudo == pse:
                return i
        return None

    def existe(self, pseudo: str) -> bool:
        for i in self.utilisateurs:
            if i.pseudo == pseudo:
                return True
        return False

    def inscrire(self,pseudo:str, mdp:str, age: int) -> str:
        maintenant = datetime.today()
        if maintenant.year - age < 15:
            return pseudo + " est trop jeune."
        for i in self.utilisateurs:
            if i.pseudo == pseudo:
                return pseudo + " est déjà inscrit."
        nouv_uti = Utilisateur(pseudo, mdp, age)
        self.utilisateurs.append(nouv_uti)
        return pseudo + " est maintenant inscrit."
