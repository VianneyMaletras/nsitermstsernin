from datetime import datetime
from utilisateur import Utilisateur
class Reseau:
    def __init__(self):
        self.get_utilisateur = []
    
    def get_utilisateur(self, pseudo: str):
        if utilisateur.get_pseudo() == pseudo
            return utilisateur
        else :
            return None
     def existe(self, pseudo: str)->bool:
            return get.utilisateur(pseudo) 