# Tests unitaires pour la fonction bien_formee
assert bien_formee("([])") == True  # Cas simple, chaîne bien formée
assert bien_formee("({[()]})") == True  # Imbrication correcte
assert bien_formee("[{()}]") == True  # Imbrication avec plusieurs types

assert bien_formee("(]") == False  # Parenthèse fermante ne correspond pas
assert bien_formee("({[}") == False  # Manque des fermetures
assert bien_formee("]") == False  # Fermeture sans ouverture
assert bien_formee("(((())))") == True  # Parenthèses imbriquées correctement
assert bien_formee("{[(])}") == False  # Parenthèses mal imbriquées

print("Tous les tests sont passés avec succès !")



# Création d'une file
file = File()

# Vérification de l'état initial (file vide)
assert file.est_vide() == True, "La file devrait être vide au départ."

# Enfiler des éléments
file.enfiler(10)
file.enfiler(20)
file.enfiler(30)
assert not file.est_vide(), "La file ne devrait pas être vide après enfiler des éléments."
assert str(file) == "File: 10 <- 20 <- 30", "La file devrait contenir les éléments dans cet ordre."

# Défiler des éléments
assert file.defiler() == 10, "Le premier élément défiler devrait être 10."
assert file.defiler() == 20, "Le deuxième élément défiler devrait être 20."
assert str(file) == "File: 30", "La file devrait contenir uniquement 30 après deux défilements."
assert file.defiler() == 30, "Le dernier élément défiler devrait être 30."

# Défiler une file vide
assert file.defiler() == -1, "Défiler une file vide devrait retourner -1."
assert file.est_vide() == True, "La file devrait être vide après avoir tout défilé."

# Réinitialisation de la file
file.enfiler(40)
file.creer_file()
assert file.est_vide() == True, "La file devrait être vide après réinitialisation."

# Test de la fonction inverser_file
file.enfiler(1)
file.enfiler(2)
file.enfiler(3)
inverser_file(file)
assert str(file) == "File: 3 <- 2 <- 1", "La file inversée devrait contenir les éléments dans l'ordre inverse."

#V2 des tests 

def tostr(file):
    """Affiche les éléments de la file sous forme lisible."""
    return "File: " + " <- ".join(map(str, file))


# Création d'une file
file = creer_file()

# Vérification de l'état initial (file vide)
assert est_vide(file)== True, "La file devrait être vide au départ."

# Enfiler des éléments
enfiler(file,10)
enfiler(file,20)
enfiler(file,30)
assert not est_vide(file), "La file ne devrait pas être vide après enfiler des éléments."
assert tostr(file) == "File: 10 <- 20 <- 30", "La file devrait contenir les éléments dans cet ordre."

# Défiler des éléments
assert defiler(file) == 10, "Le premier élément défiler devrait être 10."
assert defiler(file) == 20, "Le deuxième élément défiler devrait être 20."
assert tostr(file) == "File: 30", "La file devrait contenir uniquement 30 après deux défilements."
assert defiler(file) == 30, "Le dernier élément défiler devrait être 30."

# Défiler une file vide
assert defiler(file) == -1, "Défiler une file vide devrait retourner -1."
assert est_vide(file)== True, "La file devrait être vide après avoir tout défilé."

# Réinitialisation de la file
enfiler(file,40)
file = creer_file()
assert est_vide(file)== True, "La file devrait être vide après réinitialisation."

# Test de la fonction inverser_file
enfiler(file,1)
enfiler(file,2)
enfiler(file,3)
inverser_file(file)
assert tostr(file) == "File: 3 <- 2 <- 1", "La file inversée devrait contenir les éléments dans l'ordre inverse."
