from reseau import Reseau

reseau_jay = Reseau()
assert reseau_jay.inscrire("superprof","1234567890",1977) == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345")




#avec assert not prof.set_mdp("12345") on vérifie que le mot de passe du prof n'est pas 12345,il renvoie True.

"""
Vous devez revoir la POO. Vous oubliez beaucoup de self. Il faut refaire les exercices
Non noté rattrapage après les vacances. 
"""