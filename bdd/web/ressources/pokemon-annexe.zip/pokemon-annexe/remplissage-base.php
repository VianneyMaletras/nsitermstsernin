<?php
    function recupererParam($conn, $pok, &$tabGarder, $quelParam){
        /*
        rempli les tables type ou weaknesses
        conserve les paramètres déjà insérés, dans tabGarder
        */
        foreach ($pok[$quelParam] as $t){
            if (!in_array($t, $tabGarder)){
                array_push($tabGarder, $t);
                $queryParam = "INSERT INTO $quelParam (nom) VALUES ('$t')";
                if (mysqli_query($conn, $queryParam)) {
                    echo "insertion $quelParam $t <br>";
                } else {
                    echo "Erreur insertion: " . mysqli_error($conn);
                }
            }
        }
    }

    function insererAffectation($conn, $quelParam, $pok){
        /*
        rempli les tables affectation_... en récupérant les id
        des paramètres dans les tables type ou weaknesses
        */
        foreach ($pok[$quelParam] as $param){
            $id = $pok["id"];
            // sous requête pour récupérer l'id du paramètre
            $ssQuery = "..."; 
            // insertion dans affectation_...           
            $queryAffectation = "...";
            if (mysqli_query($conn, $queryAffectation)) {
                echo "insertion affectation $param <br>";
            } else {
                echo "Erreur insertion: " . mysqli_error($conn);
            }
        }
    }

    // Initialisation de la connexion
    $servername = "localhost";
    $dbname = "pokemon";
    $username = "bigboss";
    $password = "supermdp";

    $connexion = mysqli_connect($servername, $username, $password, $dbname) or die ("connexion impossible");

    //lecture du json
    $jsonFichier = file_get_contents("pokedex.json");
    $tabPok = json_decode($jsonFichier, true)["pokemon"];

    $types=[];
    $faiblesses=[];
    // parcours des pokemon
    foreach ($tabPok as $pok){
        $id = $pok['id'];
        echo "<br>INSERTIONS POUR POKEMON $id <br>";
        // RÉCUPÉRATION DES PARAMÈTRES
        recupererParam($connexion, $pok, $types, "type");
        recupererParam($connexion, $pok, $faiblesses, "weaknesses");
        
        // INSERTION DES POKÉMONS
        // ces 3 données sont des strings
        $name = $pok['name'];
        $poids = $pok['weight'];
        $taille = $pok['height'];
        $query = "INSERT INTO pok (id, nom, poids, taille) VALUES ($id, '$name', '$poids', '$taille')";

        if (mysqli_query($connexion,$query)) {
            echo "insertion " . $pok['name'] . "<br>";
        } else {
            echo "Erreur insertion: " . mysqli_error($connexion);
        }

        // AFFECTATIONS DES PARAMÈTRES
        insererAffectation($connexion, "type", $pok);
        insererAffectation($connexion, "weaknesses", $pok);
    }


// fermeture de la connexion
mysqli_close($connexion);
?> 
