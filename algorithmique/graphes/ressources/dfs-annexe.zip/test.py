#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Sunday 13 February 2022 21:23
"""

import unittest
import csv
from dfs import graphe


class Test(unittest.TestCase):
    def setUp(self):
        fichier = open("test.csv", "r")
        donnees = csv.reader(fichier)
        self.g = []
        for ligne in donnees:
            nouvelle = []
            for val in ligne:
                nouvelle.append(int(val))
            self.g.append(nouvelle)

        fichier.close()

    def test_matrice(self):
        self.assertTrue(graphe == self.g)


if __name__ == "__main__":
    unittest.main()
