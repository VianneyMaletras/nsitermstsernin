class Utilisateur:
    def __init__(self,pseudo:str,mdp:str,naissance:int):
        self.get_pseudo
        self.get_mdp
        self.get_naissance
        self.tab_amis=[]


    def set_mdp(self)->bool:
        self.mdp=" "
        if len(self.mdp)>= 10:
            return True
        else:
            return False



    def ajouter_ami(self,ami,pseudo)->str:
        if pseudo not in self.tab_amis:
            tab_amis.append(pseudo)
            return self.pseudo+ " est ton nouvel ami"
        else:
            return self.pseudo+ "est deja ton ami"




