class Utilisateur:
    def __init__(self, p: str, m: str, d: int):
        self.pseudo = p
        self.mdp = m
        self.annee_naissance = d
        self.ami = []

    def get_pseudo(self):
        return self.pseudo

    def get_mdp(self, nouveau: str) -> bool:
        if len(nouveau) >= 9:
            self.mdp = nouveau
            return True
        return False

    def get_naissance(self):
        return self.annee_naissance

    def ajouter_ami(self, ami):
        if ami not in self.ami:
            self.ami.append(ami)
            return ami.get_pseudo() +" est ton nouvel ami."
        else:
            return ami.get_pseudo() +" est déjà ton ami."