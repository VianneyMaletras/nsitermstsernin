from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur(self, pseudo_x: str) -> Utilisateur:
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo_x:
                return utilisateur
        return None

    def existe(self, pseudo_y: str) -> bool:
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo_y:
                return True
        return False

    def inscrire(self, pseudo_u: str, mdp: str, date: int) -> str:
        if self.existe(pseudo_u):
            return "superprof est déjà inscrit."
        elif date > 2006:
            return f"{pseudo_u} est trop jeune."
        else:
            nouvel_utilisateur = Utilisateur(pseudo_u, mdp, date)
            self.utilisateurs.append(nouvel_utilisateur)
            return f"{pseudo_u} est maintenant inscrit."



