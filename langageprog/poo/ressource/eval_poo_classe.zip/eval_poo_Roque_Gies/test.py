from reseau import Reseau

reseau_jay = Reseau()
inscrit=reseau_jay.inscrire("superprof","1234567890",1977)
assert inscrit == "superprof est maintenant inscrit."
inscrit= reseau_jay.inscrire("supereleveNSI","azertyazerty",2005)
assert inscrit == "supereleveNSI est maintenant inscrit."
inscrit=reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011)
assert inscrit == "elevebasique est trop jeune."
# inscrit=reseau_jay.inscrire("superprof","un grand mot de passe",2000)
# assert inscrit  == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345") #ca ne marche pas car il n y a pas au moins 10 caractere


"""
Bon travail avec quelques innatentions que vous auriez pu éviter en écrivant votre algo !
Vous n'avez pas utilisé la bibliothèque datetime. 
Vous avez oublié de vérifier si la personne est déja inscrite avant de l'inscrire
Vous avez raté le get utilisateur qui doit aller chercher un utilisateur et vous y avez mis des print au lieu de return ce qui fait que vos objets prof et eleves sont vides. 
Je vous met 15 pour vous encourager dans vos efforts. 
"""