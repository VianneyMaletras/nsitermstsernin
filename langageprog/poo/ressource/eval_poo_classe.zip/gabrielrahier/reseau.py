from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        # Initialisation attribut utilisateurs avec tableau vide
        self.utilisateurs = []

    # Méthode récupérer un utilisateur par son pseudo
    def get_utilisateur(self, pseudo):
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None

    # Méthode vérifi si un utilisateur existe par son pseudo
    def existe(self, pseudo):
        return self.get_utilisateur(pseudo) is not None

    # Méthode inscrire un nouvel utilisateur
    def inscrire(self, pseudo, mot_de_passe, annee_de_naissance):
        if self.existe(pseudo):
            return f"{pseudo} est déjà inscrit."

        # Vérification âge minimum
        age_minimum = 18
        annee_actuelle = 2024
        if annee_actuelle - annee_de_naissance < age_minimum:
            return f"{pseudo} est trop jeune."

        # Ajout du nouvel utilisateur si il est éligible
        nouvel_utilisateur = Utilisateur(pseudo, mot_de_passe, annee_de_naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        return f"{pseudo} est maintenant inscrit."