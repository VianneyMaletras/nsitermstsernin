from datetime import datetime
from utilisateur import Utilisateur


class Reseau :
    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur (self,pseudo):
        for i in range(len(self.utilisateurs)):
            #if self.utilisateurs[i] == Utilisateur.pseudo:
            if self.utilisateurs[i].get_pseudo() == pseudo:
                return self.utilisateurs[i]
                #return Utilisateur
            # else :
            #     return None
        return None # innatention le return est en dehors de la boucle si non vous n'examinez que le premier 

    def existe (self,pseudo):
        for i in range(len(self.utilisateurs)):
            #if self.utilisateurs[i] == Utilisateur.pseudo:
            if self.utilisateurs[i].get_pseudo() == pseudo:
                return True
            else :
                return False
    def inscrire(self,pseudo,mdp,naissance):
        resultat = pseudo
        maintenant = datetime.today()
        # age = maintenant.year - naissance.year Excellent ça m'a fait rire
        age = maintenant.year - naissance
        if self.existe(pseudo) == True :
            resultat += " est déjà inscrit."
        else :
            if age < 15 :
                 resultat += " est trop jeune."
            else :
                #self.utilisateurs += Utilisateur(pseudo,mdp,naissance) # Revoir l'ajout dans les tableaux
                self.utilisateurs.append(Utilisateur(pseudo,mdp,naissance))
                resultat +=" est maintenant inscrit."# il manquait le point
        return resultat


















