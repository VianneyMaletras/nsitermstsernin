from datetime import datetime
from utilisateur import Utilisateur

class Reseau:
    def __init__(self):
        self.utilisateurs = []

    def get_utilisateur(self, pseudo):
        for utilisateur in self.utilisateurs:
            if utilisateur.get_pseudo() == pseudo:
                return utilisateur
        return None

    def existe(self, pseudo):
        return any(utilisateur.get_pseudo() == pseudo for utilisateur in self.utilisateurs)

    def inscrire(self, pseudo, mdp, naissance):
        if self.existe(pseudo):
            return pseudo+ " est déjà inscrit."
        maintenant = datetime.today()
        annee_mtn = maintenant.year
        age = annee_mtn - naissance
        if age < 15:
            return pseudo+ " est trop jeune."
        nouvel_utilisateur = Utilisateur(pseudo, mdp, naissance)
        self.utilisateurs.append(nouvel_utilisateur)
        message = pseudo+ " est maintenant inscrit."
        return message
