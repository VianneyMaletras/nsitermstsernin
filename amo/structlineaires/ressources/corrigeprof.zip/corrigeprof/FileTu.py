import unittest

class TestFile(unittest.TestCase):
    def setUp(self):
        """Création d'une instance de File avant chaque test."""
        self.file = File()

    def test_creer_file(self):
        """Test de la méthode creer_file."""
        self.file.enfiler(10)
        self.file.creer_file()
        self.assertTrue(self.file.est_vide(), "La file devrait être vide après réinitialisation.")

    def test_est_vide(self):
        """Test de la méthode est_vide."""
        self.assertTrue(self.file.est_vide(), "La file devrait être vide initialement.")
        self.file.enfiler(5)
        self.assertFalse(self.file.est_vide(), "La file ne devrait pas être vide après enfiler.")

    def test_enfiler(self):
        """Test de la méthode enfiler."""
        self.file.enfiler(10)
        self.file.enfiler(20)
        self.assertEqual(str(self.file), "File: 10 <- 20", "Les éléments ajoutés ne sont pas correctement ordonnés.")

    def test_defiler(self):
        """Test de la méthode defiler."""
        self.file.enfiler(10)
        self.file.enfiler(20)
        self.file.enfiler(30)
        self.assertEqual(self.file.defiler(), 10, "Le premier élément défilé devrait être 10.")
        self.assertEqual(self.file.defiler(), 20, "Le deuxième élément défilé devrait être 20.")
        self.assertEqual(self.file.defiler(), 30, "Le troisième élément défilé devrait être 30.")
        self.assertEqual(self.file.defiler(), -1, "Défiler une file vide devrait retourner -1.")

    def test_inverser_file(self):
        """Test de la fonction inverser_file."""
        self.file.enfiler(1)
        self.file.enfiler(2)
        self.file.enfiler(3)
        inverser_file(self.file)
        self.assertEqual(str(self.file), "File: 3 <- 2 <- 1", "La file inversée n'est pas correcte.")
