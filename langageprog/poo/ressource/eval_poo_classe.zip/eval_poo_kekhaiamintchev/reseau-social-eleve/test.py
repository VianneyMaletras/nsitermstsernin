from reseau import Reseau

reseau_jay = Reseau()
assert reseau_jay.inscrire("superprof","1234567890",1977) == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
#print(eleve.ajouter_ami(prof))
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345")
""" Autrement dit:
    prof.set_mdp("12345") == False
    on vérifie qu'on ne peut pas mettre "12345" en mdp car c'est trop court
"""
"""
Perfect 20/20
"""