from jeu import Jeu

# crée un jeu
jeu = ...
# mélange le jeu
jeu....
for carte in jeu.get_paquet():
    print(carte...., carte...., carte....)
