from utilisateur import Utilisateur
class Reseau :
    def __init__(self):
        self.utilisateurs=[]
    def get_utilisateur(self,pseudo):
        if self.utilisateurs.count(pseudo)==1 :
            print(Utilisateur)
        else: print(None)
    def existe(self,pseudo):
        if self.utilisateurs.count(pseudo)==1:
            print(True)
        else:print(False)
    def inscrire (self,pseudo:str,mdp:str,annee:int):
        if self.utilisateurs.count(pseudo)==1:
            return pseudo+" est déjà inscrit."
        #if annee<=2009: ## innatention  ^^ et pk 2009? nous sommes en 2024
        if 2024- annee<=15: ## innatention  ^^
            return pseudo+" est trop jeune."
        else :
            self.utilisateurs.append(Utilisateur)
        return pseudo+" est maintenant inscrit."


