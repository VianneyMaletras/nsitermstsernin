from datetime import datetime
import locale
locale.setlocale(locale.LC_TIME,'')

class Utilisateur:
    def __init__(self, ident: str, mdp: str):
        self.identifiant = ident
        self.mot_de_passe = mdp

    def verifier_mdp(self, mdp_saisi: str) -> bool:
        return self.mot_de_passe == mdp_saisi

    def get_identifiant(self) -> str:
        return self.identifiant

    def set_identifiant(self, nouveau: str) -> None:
        self.identifiant = nouveau

    def get_mdp(self) -> str:
        return self.mot_de_passe

    def set_mdp(self, nouveau: str) -> None:
        if len(nouveau) >= 8:
            self.mot_de_passe = nouveau


class Log:
    def __init__(self, ident: str, res: str, adr: str):
        self.identifiant = ...
        self.resultat = ...
        self.adresse_ip = ...
        self.timestamp = datetime.now().strftime("%d %B %Y, %H:%M -")

    def afficher(self) -> str:
        return (
            self.timestamp
            + " Tentative de "
            + self.identifiant
            + " depuis "
            + self.adresse_ip
            + " : "
            + self.resultat
        )


class Journal:
    ...


class Systeme_auth:
    def __init__(self):
        self.utilisateurs = {}
        self.journal = ...

    def ajouter_utilisateur(self, util: Utilisateur) -> None:
        self.utilisateurs[...] = ...

    def connexion(self, ident: str, mdp: str, ip: str) -> str:
        resultat = "Échec"
        if ident in self.utilisateurs:
            utilisateur = self.utilisateurs[ident]
            # Vérification du mdp
            if utilisateur....(mdp):
                resultat = "Succès"
        # Création du log de connexion
        log = Log(...)
        # Enregistrement dans le journal de log
        self.journal....(log)
        return resultat == "Succès"
