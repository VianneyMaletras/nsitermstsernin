from datetime import datetime
from utilisateur import Utilisateur
datetime.today()

class Reseau:
    #def __init__(self,utilisateurs):
    def __init__(self):
        self.tab_utilisateurs=[]
        self.get_utilisateur
        self.pseudo_utilisateur


    def get_utilisateur(self,utilisateur)->None:
        #if self.pseudo_utilisateur not in tab_utilisateurs:
        if self.pseudo_utilisateur not in self.tab_utilisateurs:
            return None


    def presence_utilisateur(self,utilisateur)->bool:
        # if self.pseudo_utilisateur in tab_utilisateurs:
        if self.pseudo_utilisateur in self.tab_utilisateurs:
            return True
        else:
            return False



    # def inscrire(pseudo_utilisateur:str,mdp:str,naissance:int)->str:
    #     #if pseudo==tab_utilisateurs:
    #     if pseudo==tab_utilisateurs:
    #         return "pseudo deja inscrit"
    #     if naissance<2024-15:
    #         return self.pseudo + " est trop jeune"
    #     else:
    #         tab_utilisateurs.append(pseudo)
    #         return self.pseudo+"est maintenant inscrit"

    def inscrire(self, p: str, m: str, d: int) -> str:
        annee = datetime.now().year
        if self.existe(p):
            return p + " est déjà inscrit."
        elif d + 18 > annee:
            return p + " est trop jeune."
        else:
            nouveau = Utilisateur(p, m, d)
            self.utilisateurs.append(nouveau)
            return p + " est maintenant inscrit."




#   maintenant = datetime.today()
#   maintenant.year
# 2024