class Pacgomme:
    def __init__(self):
        self.col = 0
        self.lig = 0
