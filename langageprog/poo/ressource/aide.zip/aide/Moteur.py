import pyxel
from constantes import *
from Fantome import Fantome
from Pacgomme import Pacgomme


class Moteur:
    def __init__(self):
        # initialisations des objets du jeu
        self.labyrinthe = self.initialiser_labyrinthe()
        self.un_fantome = Fantome(1, 1, 8)

        # initialisation de pyxel
        pyxel.init(TAILLE*TAILLE_CEL, TAILLE*TAILLE_CEL, fps=5)
        pyxel.load("ressources.pyxres")
        pyxel.run(self.update, self.draw)

    def update(self):
        """
        met à jour à chaque cycle de pyxel
        """
        self.update_fantomes()

    def draw(self):
        """
        dessine à chaque cycle de pyxel
        """
        pyxel.cls(0)
        self.dessiner_labyrinthe()
        self.dessiner_fantome(self.un_fantome)

    def initialiser_labyrinthe(self) -> list:
        """
        Crée un labyrinthe de test
        Doit normalement s'appuyer sur le fichier csv

        Renvoie:
            list: tableau représentatif du labyrinthe
        """
        return [[0, 0, 0, 0, 0],
                [0, Pacgomme(), Pacgomme(), Pacgomme(), 0],
                [0, Pacgomme(), 0, Pacgomme(), 0],
                [0, Pacgomme(), Pacgomme(), Pacgomme(), 0],
                [0, 0, 0, 0, 0],]

    def update_fantomes(self) -> None:
        """
        bouge les fantômes
        """
        self.un_fantome.choisir_dpct(self.labyrinthe)

    def dessiner_labyrinthe(self):
        for l in range(TAILLE):
            for c in range(TAILLE):
                if isinstance(self.labyrinthe[l][c], Pacgomme):
                    self.dessiner_pacgomme(c, l)
                elif self.labyrinthe[l][c] == 0:
                    self.dessiner_mur(c, l)

    def dessiner_mur(self, c: int, l: int):
        """
        dessine un mur bleu

        Params:
            c (int): colonne
            l (int): ligne
        """
        pyxel.rect(c*TAILLE_CEL, l*TAILLE_CEL, TAILLE_CEL, TAILLE_CEL, 5)

    def dessiner_fantome(self, fant: Fantome) -> None:
        """
        dessine un fantôme

        Paramètres:
            fant (Fantome): instance du fantôme dessiné
        """    
        c = fant.get_col()
        l = fant.get_lig()
        pyxel.blt(c*TAILLE_CEL, l*TAILLE_CEL, 0,
                  TAILLE_CEL, 0, TAILLE_CEL, TAILLE_CEL, 0)

    def dessiner_pacgomme(self, c: int, l: int):
        pyxel.circ((c+0.5)*TAILLE_CEL, (l+0.5) *
                   TAILLE_CEL, TAILLE_CEL//5, 10)


# programme principal
Moteur()
