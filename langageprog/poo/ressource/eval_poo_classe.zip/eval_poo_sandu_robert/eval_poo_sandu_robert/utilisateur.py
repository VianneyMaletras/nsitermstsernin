class Utilisateur:
    #def __init__(self, pseudo : str, mdp : str, naissance : int, amis):     
    def __init__(self, pseudo : str, mdp : str, naissance : int) :  
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.amis = []
        
    def get_pseudo(self) :
        return self.pseudo
    
    def get_mdp(self):
        return self.mdp
    
    def get_naissance(self):
        return self.naissance
    
    def set_mdp(self, nouveau_mdp : str):
        if len(nouveau_mdp) >= 10:
            self.mdp = nouveau_mdp
            return True
        else:
            return False
        
    def ajouter_ami(self, autre_utilisateur : str):
        if autre_utilisateur not in self.amis:
            self.amis.append(autre_utilisateur)
            return f"{autre_utilisateur.get_pseudo()} est ton nouvel ami."
        else :
            return f"{autre_utilisateur.get_pseudo()} est déjà ton ami."