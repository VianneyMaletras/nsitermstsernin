from reseau import Reseau

reseau_jay = Reseau()
assert reseau_jay.inscrire("superprof","1234567890",1977) == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
assert reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011) == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

# Cette méthode vérifie si le nouveau mot de passe a une longueur d'au moins 10 caractères.
# Comme "12345" contient seulement 5 caractères, la condition est fausse
# La méthode set_mdp renvoie donc False, indiquant que le mot de passe n'a pas été modifié.
assert not prof.set_mdp("12345")


""" Parfait 20/20"""


