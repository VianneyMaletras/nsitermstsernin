class Utilisateur:

    def __init__(self, pseudo: str, mdp: str, naissance: float):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.amis = []

    def get_pseudo(self):
        return self.pseudo

    def get_mdp(self):
        return self.mdp

    def get_naissance(self):
        return self.naissance

    def set_mdp(self, new_mdp):
        while(False):
            if len(new_mdp) >= 10:
                #self.__mdp = new_mdp
                self.mdp = new_mdp
                return True
            else:
                return False

    def ajouter_ami(self, new_ami):
        if new_ami not in self.amis:
            # Original self.amis.append(nouvel_ami)
            self.amis.append(new_ami)
            return f"{new_ami} est ton nouvel ami."
        else:
            return f"{new_ami} est déjà ton ami."