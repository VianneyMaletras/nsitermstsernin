from reseau import Reseau

reseau_jay = Reseau()
inscrit=reseau_jay.inscrire("superprof","1234567890",1977)
assert inscrit == "superprof est maintenant inscrit."
assert reseau_jay.inscrire("supereleveNSI","azertyazerty",2005) == "supereleveNSI est maintenant inscrit."
inscrit=reseau_jay.inscrire("elevebasique","ksA2jioaedjfncaozdj@&",2011)
assert  inscrit == "elevebasique est trop jeune."
assert reseau_jay.inscrire("superprof","un grand mot de passe",2000) == "superprof est déjà inscrit."

prof = reseau_jay.get_utilisateur("superprof")
eleve = reseau_jay.get_utilisateur("supereleveNSI")
assert eleve.ajouter_ami(prof) == "superprof est ton nouvel ami."
assert eleve.ajouter_ami(prof) == "superprof est déjà ton ami."

assert not prof.set_mdp("12345")

## la dèrniere ligne vérifie que la metode set_mdp ne valide pas le mot de pass "12345" car il a moin de 10 caractéres

# Bon travail des erreurs d'innatention évitables en écrivant votre algo  15/20