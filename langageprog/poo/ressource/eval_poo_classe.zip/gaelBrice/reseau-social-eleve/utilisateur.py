class Utilisateur:
    def __init__ (self, p:str , m: str ,a: int):
        self.pseudo = p
        self.mdp = m
        self.naissance = a
        self.amis = []
    
    def get_pseudo(self):
        return self.pseudo
    
    def get_mdp(self):
        return self.mdp
    
    def get_naissance(self):
        return self.naissance
    

    def set_mdp(self,nouveaux_mdp):
        if len(nouveaux_mdp) > 10 :
            self.mdp = nouveaux_mdp 
            return True
        else :
            return False
    
    def ajouter_ami(self,Utilisateur):
        resultat = Utilisateur.pseudo 
        for i in range(len(self.amis)):
            if self.amis[i] == Utilisateur :
                resultat += "est déjà ton ami"
            else :
                resultat += "est ton nouvel ami"
        return resultat
    

    
                

        

    
   