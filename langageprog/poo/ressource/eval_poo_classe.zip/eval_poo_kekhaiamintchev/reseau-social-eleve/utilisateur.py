class Utilisateur:
    def __init__(self, pseudo: str, mdp: str, age: int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.age = age
        self.amis = []

    def get_pseudo(self) -> str:
        return self.pseudo

    def get_mdp(self) -> str:
        return self.mdp

    def get_age(self) -> int:
        return self.age

    def set_mdp(self, nouv_mdp: str) -> bool:
        if len(nouv_mdp) >= 10:
            self.mdp = nouv_mdp
            return True
        else:
            return False

    def ajouter_ami(self, Utilisateur) -> str:
        if Utilisateur not in self.amis:
            self.amis.append(Utilisateur)
            return Utilisateur.pseudo + " est ton nouvel ami."
        else:
            return Utilisateur.pseudo + " est déjà ton ami."
