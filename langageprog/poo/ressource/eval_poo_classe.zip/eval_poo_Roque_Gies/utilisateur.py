
class Utilisateur:
    def __init__(self,pseudo:str,mdp:str,annee:int):
        self.pseudo=pseudo
        self.mdp=mdp
        self.naissance=annee
        self.amis=[]
    def get_pseudo(self):
        self.aunpseudo=self.pseudo
    def get_mdp(self):
        self.aunmdp=self.mdp
    def get_naissance(self):
        self.auneannee=self.naissance
    def set_mdp (self,newmdp:str):
        self.nouveaumdp=newmdp
        if len(newmdp)>=10:
            True
            self.aunmdp=self.nouveaumdp
        else :False

    def ajouter_ami(self,Utilisateur):
        self.amis.append(Utilisateur)
        if self.amiscount(Utilisateur)==1:
            print(Utilisateur,"est ton ami")
        else : self.amis.remove(Utilisateur) #j'ai regarde sur internet pour le remove
        print(Utilisateur,"est deja ton ami")

