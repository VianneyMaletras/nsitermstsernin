class Utilisateur:
    def __init__(self, pseudo: str, mdp: str, naissance: int):
        self.pseudo = pseudo
        self.mdp = mdp
        self.naissance = naissance
        self.amis = []  # Tableau vide pour stocker les amis

    # Méthodes d'accès (accesseurs)
    def get_pseudo(self):
        return self.pseudo

    def get_mdp(self):
        return self.mdp

    def get_naissance(self):
        return self.naissance

    # Méthode pour modifier le mot de passe
    def set_mdp(self, nouveau_mdp: str) -> bool:
        if len(nouveau_mdp) >= 10:
            self.mdp = nouveau_mdp
            return True
        return False

    # Méthode pour ajouter un ami
    def ajouter_ami(self, ami):
        if ami not in self.amis:
            self.amis.append(ami)
            return f"{ami.get_pseudo()} est ton nouvel ami."
        return f"{ami.get_pseudo()} est déjà ton ami."
